<?php
    class Conectar{
        static public function conexion(){
            $bd = new PDO("mysql:host=localhost;dbname=nombrebd","root","12345");
            $bd -> exec("set names utf8");
            return $bd;
        }
    }
