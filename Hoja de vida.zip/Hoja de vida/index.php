<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hoja de vida CSS</title>
    <!-- Iconos -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <!-- Estilos -->
    <link rel="stylesheet" href="/Style/Estilos.css">
</head>
<body>
    <div class="principal">
        <header>
            <nav class="navbar">
                <div class="logo">
                    <h2>Samuel David <span>Pedreros Gamez</span></h2>
                </div>
                <ul class="menu">
                    <li>
                        <a href="#home">Inicio</a>
                    </li>
                    <li><a href="#about">Descripcion</a></li>
                    <li><a href="#fortalezas">Fortalezas</a></li>
                    <li><a href="#estudios">Estudios</a></li>
                    <li><a href="#contacto">Contacto</a></li>
                </ul>
            </nav>
        </header>
        <main class="main">
            <div class="info-contenido">
                <h1>Samuel Pedreros</h1>
                <p>Mi objetivo profesional es mantener un crecimiento continuo en mi vida laboral y conocimientos</p>
                <a href="ruta/hv.pdf" class="btn-download"><i class='bx bxs-file-pdf'></i>Hoja de vida</a>
            </div>
            <div class="info-image">
                <div class="photo">
                    <img src="imagen/Screenshot_1.png" alt="">
                </div>
                <h2>Ingeniero en Sistemas</h2>
                <div class="redes">
                    <a href="https://www.facebook.com/samueldavid.pedrerosgamez"><i class='bx bxl-facebook'></i></a>
                    <a href="https://twitter.com/?lang=es"><i class='bx bxl-twitter'></i></a>
                    <a href="https://www.google.com/intl/es-419/gmail/about/"><i class='bx bxl-gmail'></i></a>
                    <a href="https://www.linkedin.com/public-profile/settings?trk=d_flagship3_profile_self_view_public_profile"><i class='bx bxl-linkedin'></i></a>
                    <a href="https://wa.link/bfawvv"><i class='bx bxl-whatsapp'></i></a>
                    <a href="https://www.instagram.com/samuel_d_p_g/"><i class='bx bxl-instagram'></i></a>
                </div>
            </div>
        </main>
    </div>
    <div class="about" id="about">
        <div class="content-about">
            <h2>Descripción</h2>
            <div class="content">
                <div class="info-personal">
                    <h3>Datos personales</h3>
                    <ul>
                        <li>Samuel David Pedreros Gamez</li>
                        <li>Girardot-Cundinamarca </li>
                        <li>Fecha de nacimiento: 02/12/2003</li>
                        <li>calle 44a-n 7b-41</li>
                        <li>telefono: 1007953385</li>
                        <li>Correo: samueldavidpedrerosgamez2@gmail.com</li>
                    </ul>
                </div>
                <div class="info-intereses">
                    <h3>Intereses personales</h3>
                    <div class="intereses">Cumplir con mis objeivos</div>
                    <div class="intereses">Deporte</div>
                    <div class="intereses">Viajar</div>
                    <div class="intereses">Capacidades analiticas</div>
                    <div class="intereses">Creatividad</div>
                </div>
            </div>
        </div>
    </div>
    <div class="fortalezas" id="fortalezas">
        <div class="content-fortalezas">
            <h2>Fortalezas</h2>
            <div class="contaier">
                <div class="fortalezas-personales">
                    <ul>
                        <li>Liderar</li>
                        <li>Creatividad</li>
                        <li>Acitud positiva</li>
                        <li>paciencia</li>
                        <li>Trabajo en equipo</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="estudios" id="estudios">
        <div class="content-estudios">
            <h2>Estudios</h2>
            <div class="Madre">
                <div class="esudios_personales">
                    <ul>
                        <li>Bachiller</li>
                        <li>Tecnico en contabilidad</li>
                        <li>Basico python</li>
                    </ul>
                </div>
            </div>
            
        </div>
    </div>
    <div class="contacto" id="contacto">
        <div class="content-contacto">
            <h2>Contacto</h2>
            <div class="madreC">
                <div class="madre-conato">
                    <ul>
                        <li>Samuel David Pedreros Gamez</li>
                        <li>telefono: 1007953385</li>
                        <li>Correo: samueldavidpedrerosgamez2@gmail.com</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
    